# Sample Materials, provided under license.
# Licensed Materials - Property of IBM
# © Copyrig ht IBM Corp. 2021, 2022 All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

# Determine packages to install among requirements
list.of.packages <- c("shinydashboard", "shinyjs","dplyr","ggplot2","flexdashboard","plotly")
new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]

if(length(new.packages)) {  # check if there's anything to install
  
  # set default libpath
  if (Sys.getenv("DSX_PROJECT_DIR")!=""){                           # If we are in WSL,
    target <- paste0(Sys.getenv("DSX_PROJECT_DIR"),"/packages/R")   # default to project packages/R
  } else {                                                          # Otherwise,
    target <- .libPaths()[1]                                        # default to first libPath (default)
  }
  
  # check for other valid libpaths
  for(libpath in .libPaths()) {           # check the .libPaths
    if(file.access(libpath, 2) == 0) {    # if we have write access to a libpath, use it
      target <- libpath
      break
    }
  }
  
  # Install the packages
  print(paste("Installing ", paste(new.packages, collapse = ", "), "to", target))
  install.packages(new.packages, lib = target, repos = "http://cran.us.r-project.org")
}


if((!"plotly" %in% rownames(installed.packages()))||((packageVersion("plotly")!= "4.9.2")))
{
  packageUrl <- "https://cran.r-project.org/src/contrib/Archive/plotly/plotly_4.9.2.tar.gz"
  install.packages(packageUrl, lib = target,repos = NULL, type='source')
}


# if the packages that get installed have a different version number to development, install the correct version
if((!"shinyWidgets" %in% rownames(installed.packages()))||((packageVersion("shinyWidgets")!= "0.4.9")))
{
  packageUrl <- "https://cran.r-project.org/src/contrib/Archive/shinyWidgets/shinyWidgets_0.4.9.tar.gz"
  install.packages(packageUrl,lib = target, repos = NULL, type='source')
}


library(shiny)
library(dplyr)
library(tidyverse)
library(ggplot2) 
library(DT) # for the dataTableOutput
library(shinyjs) 
library(shinydashboard)
library(plotly)
library(rjson)
library(flexdashboard)
library(shinyWidgets)

# Load panels
source("homePage.R")
source("patientPage.R")
# Load datasets & Cloud Pak for Data API functions
source("load-data.R")
source("about.R")


############SERVER 
server <- function(input,output, session) {
  
  sessionVars <- reactiveValues(selectedClientId = 53612379)
  homeTabServer(input, output, session, sessionVars)
  clientTabServer(input, output, session, sessionVars)
 aboutTabServer(input, output, session, sessionVars)
  
  
}



ui <- dashboardPage(skin='blue',
                    dashboardHeader(
                      title = "Hospital Re-Admissions", 
                      titleWidth = 270, 
                      dropdownMenu(type = "tasks", badgeStatus = "success",
                                   taskItem(value = 30, color = "red",
                                            "Re-admission rates in early discharges"),
                                   taskItem(value = 12, color = "red",
                                            "Re-admission rates in the patients of age less than 20"),
                                   taskItem(value = 75, color = "yellow",
                                            "Backlog (last 3 months)")
                      ),
                      dropdownMenu(type = "notifications",
                                   notificationItem(
                                     text = "5 active users today",
                                     icon("users")),
                                   notificationItem(
                                     text = "2 inactive users (last 3 months)", 
                                     icon("warning"),
                                     status = "warning")
                      )),
                    
                    dashboardSidebar(
                      width = 270,
                      sidebarMenu(id = "proNav",
                                  img(src='IBM_logo.png', align = "center",  width = "270px"),
                                  menuItem("Home", tabName = "home", icon = icon("th")),
                                  menuItem("Patient View", tabName = "patient", icon = icon("user"), badgeLabel = "new", badgeColor = "orange"),
                                  #menuItem("Data Table", tabName = "table", icon = icon("table")),
                                  menuItem("About", tabName = "about", icon = icon("book-open")),
                                  #menuItem("Help", tabName = "help", icon = icon("question-circle")),
                                  style = "position: fixed; overflow: visible"
                      )),
                    
                    dashboardBody(
                      tabItems(
                        homeTab(),
                       clientTab(),
                        aboutTab()
                        
                        
                      )
                    )
)


# Run the application 
shinyApp(ui = ui, server = server)
