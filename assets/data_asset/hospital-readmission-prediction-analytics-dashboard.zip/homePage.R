homeTab <- function(){
  
  # First tab content
  tabItem(tabName = "home",
          shinyjs::useShinyjs(),
          #useShinydashboard(),
          tags$style(HTML("
                .box.box-solid.box-primary>.box-header {
                }
                .box.box-solid.box-primary{
                background:#222d32
                }
                .small-box {height: 75px}
                ")),
          
          ################# UI for the first home tab
          h2("Summary View"),
          fluidRow(
            #valueBox( "Diagnosis Analysed: Diabates", icon = icon("credit-card"), color = "purple", width = 3),
            infoBoxOutput("diagnosis", width = 3),
            infoBoxOutput("patient_count", width = 3),
            infoBoxOutput("readmission_rate", width = 3)
            #valueBox("60%", "Customer Satisfaction (last 7 days)", icon = icon("pen-nib"), color = "navy", width = 3),
          ),
          fluidRow(
            
            
            column(1,
                   
                   checkboxGroupInput("gender", "Gender",
                                      genderlist, selected=genderlist
                   ),
                   checkboxGroupInput("age", "Age Group",
                                      agelist, selected=agelist
                   )
            ),
            box(width = 5, title = "Re admission Risk Levels",
                
                plotOutput("pieadmissionrisk", height="350px", width="450px")
            ),
            box(width = 6, title = "Patient Details",
                h4("Click on a patient to drill down into more detail"),
                dataTableOutput("PatientData")
            )
            
          ),
          fluidRow(
            
            tabBox(
              title = "Admission rates within Age groups",
              id = "tabset1", height = "450",
              tabPanel("Admissions in Age Groups", plotlyOutput("ageplot")), 
              tabPanel("Readmission Rate", plotOutput("agelineplot"))
            ),
            tabBox(
              title = "Patients Payer and Discharge Information",
              id = "tabset2", height = "450",
              tabPanel("Discharge Details", plotOutput("dischargeplot")),
              tabPanel("Payer Details", plotlyOutput("payerplot"))
              
            )
          )
  )}
homeTabServer <- function(input, output, session, sessionVars){
  
  observe({
    df_filter = dplyr::filter(df_summary, (df_summary$GENDER %in% input$gender)&(df_summary$AGE %in% input$age))
    
    admission_count <- nrow(df_filter)
    readmission_count <- nrow(df_filter[df_filter$READMITTED==1,])
    if(admission_count==0){
      output$diagnosis <- renderInfoBox({
        infoBox("No matching Patients",
                admission_count,  icon = icon("th"),
                color = "light-blue", fill = TRUE
        )})
      output$patient_count <- NULL
      output$readmission_rate <- NULL
      output$pieadmissionrisk <- NULL
      output$PatientData <- NULL
      output$payerplot <- NULL
      output$dischargeplot <- NULL
      output$ageplot <- NULL
      output$agelineplot <- NULL
      
    }else{
    
    output$diagnosis <- renderInfoBox({
      infoBox( "Diagnosis Analysed",
               "Diabetes", icon = icon("hospital"),
               color = "blue", fill = TRUE
      )
    })
    output$patient_count <- renderInfoBox({
      infoBox("Total Hospital Admissions",
              admission_count,  icon = icon("th"),
              color = "light-blue", fill = TRUE
      )
    })
    
    output$readmission_rate <- renderInfoBox({
      infoBox( "Number of hospital Re-Admissions",
               readmission_count, icon = icon("bed"),
               color = "orange", fill = TRUE
      )
    })
    
    output$pieadmissionrisk <- renderPlot({
      df_pie <- data.frame(df_filter %>% group_by(CHANCES) %>% count() %>%  ungroup() %>% 
                             mutate(percentage=`n`/sum(`n`)) %>% 
                             arrange(desc(n)))
      
      # Compute the cumulative percentages (top of each rectangle)
      df_pie$ymax = cumsum(df_pie$percentage)
      df_pie$label <- scales::percent(df_pie$percentage)
      df_pie$`Re-Admission Risk` <- df_pie$CHANCES
      # Hole size
      hsize <- 2
      
      df_pie <- df_pie %>% 
        mutate(x = hsize)
      
      ggplot(df_pie, aes(x = hsize, y = percentage, fill = `Re-Admission Risk`)) +
        geom_col() +
        geom_text(aes(label = label),
                  position = position_stack(vjust = 0.5)) +
        coord_polar(theta = "y") +
        xlim(c(0.2, hsize + 0.5)) + theme_void()+
        scale_fill_brewer(palette = "YlGnBu") +   theme(plot.background = element_rect(fill = "#ECF0F5"))
      
    })
    
    
    output$PatientData <- DT::renderDataTable({
      
     
      df_filter$NAME <- paste(df_filter$FIRST_NAME,df_filter$LAST_NAME)
      df_filter$explain_binary=ifelse(df_filter$EXPLAIN=='no', 0, 1)
      df_filter=df_filter[with(df_filter, order(-explain_binary,-predicted_probability)), ]
  
      filtered_df <- select(df_filter, "PATIENT_NBR", "NAME",  "DISCHARGE_DISPOSITION_ID","CHANCES")
      
      filtered_df
    }, rownames = FALSE,colnames = c("Patient Number", "Patient Name","Discharge Disposition","Re-admission Risk" ), selection = 'single', options = list(pageLength = 5),server = FALSE, callback = JS("table.on('click.dt', 'tr', 
    function() {
           Shiny.onInputChange('customer_row',table.rows(this).data().toArray() );
    });"))
    
    output$payerplot <-  renderPlotly({
      
      df_payer <- data.frame(df_filter %>% group_by(PAYER_CODE,READMITTED) %>% count() %>%   ungroup() %>% 
                               arrange(desc(n)))
      df_payer[df_payer$READMITTED==1,]$READMITTED="Yes"
      df_payer[df_payer$READMITTED==0,]$READMITTED="No"
      df_payer$READMITTED=as.factor(df_payer$READMITTED)
      
      g<-ggplot(aes(y=n, x=reorder(PAYER_CODE, n), fill = READMITTED), data = df_payer, text = paste("Number of patients:",n)) +
        geom_bar(stat = 'identity') +
        coord_flip() +
        scale_fill_manual(values = c( "#488ef0","#ffbb3d"))+
        labs(x = "Payer", y = "No of Patients") +theme_minimal()
      
      ggplotly(g, tooltip = "text")  %>% layout(legend = list(title=list(text='<b> Readmission </b>'),x = 0.8, y = 0.2))
      
    })
    
    
    
    output$dischargeplot <-  renderPlot({
      
      df_discharge <- data.frame(df_filter %>% group_by(DISCHARGE_DISPOSITION_ID,READMITTED) %>% count() %>%   ungroup() %>% 
                                   arrange(desc(n)))
      df_discharge[df_discharge$READMITTED==1,]$READMITTED="Yes"
      df_discharge[df_discharge$READMITTED==0,]$READMITTED="No"
      
      df_discharge$READMITTED=as.factor(df_discharge$READMITTED)
      
      names(df_discharge)[names(df_discharge) == 'READMITTED'] <- 'Readmission'
      
      ggplot(aes(y=n, x= reorder(stringr::str_wrap(DISCHARGE_DISPOSITION_ID, 70),n), fill = Readmission, text=paste("Number of patients:",n)), data = df_discharge) +
        geom_col()+
        
        #geom_bar(stat = 'identity', text = "DISCHARGE_DISPOSITION_ID") +
        coord_flip() +
        scale_fill_manual(values = c( "#0099f9","#ff813d")) +
        labs(x = "Discharge Disposition", y = "No of Patients") +theme_minimal()+
        theme(legend.position = 'top', 
              legend.direction = "horizontal",
              legend.box = "horizontal")
      
      
      
      
    })
    
    df_age <- data.frame(df_filter %>% group_by(AGE,READMITTED) %>% count() %>%   ungroup() %>% 
                           arrange(desc(n))) 
    
    df_age <- data.frame(df_age %>% group_by(AGE) %>% mutate(percent = n/sum(n)))
    df_age$percent = round(df_age$percent*100,1)
    df_age[df_age$READMITTED==1,]$READMITTED="Yes"
    df_age[df_age$READMITTED==0,]$READMITTED="No"
    
    df_age$READMITTED=as.factor(df_age$READMITTED)
    #df_age <- df_age[df_age$n>10,]
    names(df_age)[names(df_age) == 'READMITTED'] <- 'READMITTED'
    
    output$ageplot<-  renderPlotly({
      age_plot<- ggplot(aes(y=n, x= AGE, fill = READMITTED, text=paste("Readmission Percentage:",percent)), data = df_age) +
        geom_col()+
        geom_line(aes(x = AGE, y = percent))+
        #geom_bar(stat = 'identity', text = "DISCHARGE_DISPOSITION_ID") +
        #coord_flip() +
        scale_fill_manual(values = c( "#3dbbff","#ff813d")) +
        labs(x = "Age Group", y = "No of Patients") +theme_minimal() #+ theme(legend.position = 'top',legend.direction = "horizontal",legend.box = "horizontal")
      
      ggplotly(age_plot) %>%
        layout(legend = list(
          orientation = "h"
        )) %>% layout(legend = list(title=list(text='<b> Readmission </b>'),x = 0.02, y = 0.96))
    })
    
    output$agelineplot <- renderPlot({
      ggplot(df_age[df_age$READMITTED=="Yes",], text=paste("Readmission Percentage:",percent))+
        #geom_bar(aes(y=n, x= age, fill = READMITTED),stat="identity")+
        geom_line(aes(x = AGE, y = percent),stat="identity",size = 0.5, color="red", group = 1) +
        scale_fill_manual(values = c( "#3dbbff","#ff813d")) +
        labs(x = "Age Group", y = "Readmission Percentage") +theme_minimal() + theme(legend.position = 'top')
    })
    
    output$weightplot<-  renderPlot({
      
      df_weight <- data.frame(df_filter %>% group_by(WEIGHT,READMITTED) %>% count() %>%   ungroup() %>% 
                                arrange(desc(n))) 
      
      df_weight <- data.frame(df_weight %>% group_by(WEIGHT) %>% mutate(percent = n/sum(n)))
      df_weight$percent = round(df_weight$percent*100,1)
      df_weight[df_weight$READMITTED==1,]$READMITTED="Yes"
      df_weight[df_weight$READMITTED==0,]$READMITTED="No"
      
      df_weight$READMITTED=as.factor(df_weight$READMITTED)
      #df_age <- df_age[df_age$n>10,]
      names(df_weight)[names(df_weight) == 'READMITTED'] <- 'READMITTED'
      ggplot(df_weight[df_weight$READMITTED=="Yes",], text=paste("Readmission Percentage:",percent))+
        #geom_bar(aes(y=n, x= age, fill = READMITTED),stat="identity")+
        geom_line(aes(x = weight, y = percent),stat="identity",size = 0.5, color="red", group = 1) +
        scale_fill_manual(values = c( "#3dbbff","#ff813d")) +
        labs(x = "Weight Group", y = "No of Patients") +theme_minimal() + theme(legend.position = 'top')
    })
    
    }
  } )
  
  observeEvent(input$customer_row, {
    
    selected_recordID <- input$customer_row[1]
    sessionVars$selectedClientId <- selected_recordID
    
    updateTabItems(session,"proNav", selected = "patient")
    # "proNav",
    
  })
  
}


