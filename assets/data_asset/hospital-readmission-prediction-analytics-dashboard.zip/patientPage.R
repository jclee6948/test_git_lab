clientTab <- function(){
  tabItem(tabName = "patient",
          shinyjs::useShinyjs(),
          tags$style(HTML("
                      .html-widget.gauge svg {
                        height: 400px;
                        width: 400px;
                      }
                     
                      ")),
       
          
          fluidRow(
            h3("Patient Details", class="text-center"),
            box(width = 4, uiOutput("patientInfo1")),
            box(width = 4,  uiOutput("patientInfo2")),
            box(width = 4,  uiOutput("patientInfo3"))
            ),
          
          
          fluidRow(
            h3("Patients Medical  Records", class="text-center"), 
            
            box(
              width = 12,
                     p(htmlOutput('medicalrecord_text'),
                       br(), 
                       actionButton("medicalrecord_button", "Medical Records", icon("calendar"), style="color: #fff; background-color: #222D31; border-color: #222D31")),
              hidden(tags$div(id = "medicalbox",
                       box(width = 3, htmlOutput("medicaldetails1")),
                        box(width = 3,  htmlOutput("medicaldetails2")),
                        box(width = 3,  htmlOutput("medicaldetails3")),
                        box(width = 3,  htmlOutput("medicaldetails4"),style='border-right'),
                       actionButton("hide", "Hide",  style='padding:2px; font-size:40%')
                       
              ))
        )
        
        ),
  fluidRow(
    h3("Re-admission Prediction", class="text-center"),
    box(width=6, 
        p(
        htmlOutput('prediction_text'),
        br(),
        actionButton("prediction_button", "Predict Re-admission", icon("paper-plane"), style="color: #fff; background-color: #222D31; border-color: #222D31"),
        #column(width = 4, gaugeOutput("gauge")),
        ),
        hidden(tags$div(id = "readmissionpredictionbox",
        #br(),
        gaugeOutput("gauge",width=4),
        br(),
        br(),
        br(),
        br(),
        br(),
        br(),
        br(),
        htmlOutput('predictionresult_text'),
        br()))
),
        
        
      hidden(tags$div(id = "explanationbox",
      box(width=6,
             
          p(htmlOutput('explanation_text'),
          br(),
          actionButton("explanation_button", "Explanation", icon("paper-plane"), style="color: #fff; background-color: #222D31; border-color: #222D31")),  
          plotOutput("explain_plot"),
          htmlOutput('explanation_text2')
            )))
    
  
  )
  #fluidRow(
  #column(width = 12, infoBoxOutput("ReadmissionRisk")))
  

  )
  
}

clientTabServer <- function(input, output, session, sessionVars){

    observeEvent(sessionVars$selectedClientId,{

    shinyjs::hide(id = "medicalbox")
    shinyjs::hide(id = "readmissionpredictionbox")
      
    #shinyjs::hide(id = "ReadmissionRisk")
    
    shinyjs::hide(id="explanation_button")
    shinyjs::hide(id="explanation_text")
    shinyjs::hide(id="explanation_text2")
    shinyjs::hide(id="explain_plot")
    shinyjs::hide(id="explanationbox")

    print(sessionVars$selectedClientId)
    selectedpatientnbr <- sessionVars$selectedClientId

    df_patient <- df_summary[df_summary$PATIENT_NBR==selectedpatientnbr,]
    df_patient$NAME <- paste(df_patient$FIRST_NAME,df_patient$LAST_NAME)
    pat_name <- df_patient$NAME
    
    output$patientInfo1 <- renderUI({
      
      tags$ul( class = 'list-unstyled',
               tags$li(
                 tags$strong('Patient Name: '), tags$span(class = "pull-right", pat_name)
               ),
               tags$li(
                 tags$strong('Patient Number: '), tags$span(class = "pull-right", selectedpatientnbr)
               ),
               tags$li(
                 tags$strong('Gender: '), tags$span(class = "pull-right", df_patient$GENDER)
               ),
               tags$li(
                 tags$strong('Age Group: '),tags$span(class = "pull-right", df_patient$AGE)
               ),
               tags$li(
                 tags$strong('Weight Group: '), tags$span(class = "pull-right", df_patient$WEIGHT)
               ),
               tags$li(
                 tags$strong('Admission Type: '), tags$span(class = "pull-right", df_patient$ADMISSION_TYPE_ID)
               )
               
      )
    })
    
    output$patientInfo2 <- renderUI({
      
      tags$ul( class = 'list-unstyled',
               
               tags$li(
                 tags$strong('Admission Source: '), tags$span(class = "pull-right", df_patient$ADMISSION_SOURCE_ID)
               ),
            
               tags$li(
                 tags$strong('Discharge Disposition: '), tags$span(class = "pull-right", df_patient$DISCHARGE_DISPOSITION_ID)
               ),
               tags$li(
                 tags$strong('Time in hospital(in days): '), tags$span(class = "pull-right", df_patient$TIME_IN_HOSPITAL)
               ),
               tags$li(
                 tags$strong('Payer Code: '), tags$span(class = "pull-right", df_patient$PAYER_CODE)
               ),
               tags$li(
                 tags$strong('Number of Lab Procedures: '), tags$span(class = "pull-right", df_patient$NUM_LAB_PROCEDURES)
               ),
               tags$li(
                 tags$strong('Number of Procedure: '),tags$span(class = "pull-right", df_patient$NUM_PROCEDURES)
               )
               
      )
    })
    output$patientInfo3 <- renderUI({
      
      tags$ul( class = 'list-unstyled',
    tags$li(
      tags$strong('Number of Medications: '), tags$span(class = "pull-right", df_patient$NUM_MEDICATIONS)
    ),
    tags$li(
      tags$strong('Number of Diagnoses: '), tags$span(class = "pull-right", df_patient$NUMBER_DIAGNOSES)
    ),
    tags$li(
      tags$strong('Diagnosis Type 1: '), tags$span(class = "pull-right", df_patient$DIAG_1)
    ),
    tags$li(
      tags$strong('Diagnosis Type 2: '), tags$span(class = "pull-right", df_patient$DIAG_2)
    ),
    tags$li(
      tags$strong('Diagnosis Type 3: '), tags$span(class = "pull-right", df_patient$DIAG_3)
    ),
    tags$li(
      tags$strong('A1C Result: '), tags$span(class = "pull-right", df_patient$A1CRESULT)
    )
      )
    })
    
    
    output$medicalrecord_text <- renderText({
      paste("Click on below button to access ",pat_name,"'s medical records.")
    })
    output$prediction_text <- renderText({
      paste("The model predicts",pat_name,"'s risk of readmission within 30 days of discharge. <br/>Click below to predict readmission</b>.<br/> " )
    })
    
    output$explanation_text <- renderText({
      paste("The model allows you to calculate the explanation of each prediction, to support you understanding better why the Model reached this conclusion. Click below to learn how the prediction was calculated.")
    })
    output$explanation_text2 <- renderText({
      paste("For more detailed explanations, visit Watson Openscale monitor. Watson Openscale can be configured using monitor-wml-model-with-Watson-OpenScale notebook")
    })
    
    })
    observeEvent(input$medicalrecord_button,{

      shinyjs::show(id = "medicalbox")
      selectedpatientnbr <- sessionVars$selectedClientId
      
      df_patient <- df_summary[df_summary$PATIENT_NBR==selectedpatientnbr,]
      df_patient$NAME <- paste(df_patient$FIRST_NAME,df_patient$LAST_NAME)
      pat_name <- df_patient$NAME
      
      output$medicaldetails1 <- renderUI({
        
        tags$ul( class = 'list-unstyled',
                 tags$li(
                   tags$strong('Max Glu Serum: '), tags$span(class = "pull-right", df_patient$MAX_GLU_SERUM)
                 ),
                 tags$li(
                   tags$strong('Insulin: '), tags$span(class = "pull-right", df_patient$INSULIN)
                 ),
                 tags$li(
                   tags$strong('Metformin: '), tags$span(class = "pull-right", df_patient$METFORMIN)
                 ),
                 tags$li(
                   tags$strong('Repaglinide: '), tags$span(class = "pull-right", df_patient$REPAGLINIDE)
                 ),
                 tags$li(
                   tags$strong('Nateglinide: '), tags$span(class = "pull-right", df_patient$NATEGLINIDE)
                 ),
                 tags$li(
                   tags$strong('Chlorpropamide: '), tags$span(class = "pull-right", df_patient$CHLORPROPAMIDE)
                 )
                 
        )
      }) 
      
      output$medicaldetails2 <- renderUI({
        
        tags$ul( class = 'list-unstyled',
                 tags$li(
                   tags$strong('Glimepiride: '), tags$span(class = "pull-right", df_patient$GLIMEPIRIDE)
                 ),
                 tags$li(
                   tags$strong('Acetohexamide: '), tags$span(class = "pull-right", df_patient$ACETOHEXAMIDE)
                 ),
                 tags$li(
                   tags$strong('Glipizide: '), tags$span(class = "pull-right", df_patient$GLIPIZIDE)
                 ),
                 tags$li(
                   tags$strong('Glyburide: '), tags$span(class = "pull-right", df_patient$GLYBURIDE)
                 ),
                 tags$li(
                   tags$strong('Tolbutamide: '), tags$span(class = "pull-right", df_patient$TOLBUTAMIDE)
                 ),
                 tags$li(
                   tags$strong('Pioglitazone: '), tags$span(class = "pull-right", df_patient$PIOGLITAZONE)
                 )
                 
        )
      }) 
      output$medicaldetails3 <- renderUI({
        
        tags$ul( class = 'list-unstyled',
                 tags$li(
                   tags$strong('Rosiglitazone: '), tags$span(class = "pull-right", df_patient$ROSIGLITAZONE)
                 ),
                 tags$li(
                   tags$strong('Acarbose: '), tags$span(class = "pull-right", df_patient$ACARBOSE)
                 ),
                 tags$li(
                   tags$strong('Miglitol: '), tags$span(class = "pull-right", df_patient$MIGLITOL)
                 ),
                 tags$li(
                   tags$strong('Troglitazone: '), tags$span(class = "pull-right", df_patient$TROGLITAZONE)
                 ),
                 tags$li(
                   tags$strong('Tolazamide: '), tags$span(class = "pull-right", df_patient$TOLAZAMIDE)
                 ),
                 tags$li(
                   tags$strong('Examide: '), tags$span(class = "pull-right", df_patient$EXAMIDE)
                 )
                 
        )
      }) 
      output$medicaldetails4 <- renderUI({
        
        tags$ul( class = 'list-unstyled',
                 tags$li(
                   tags$strong('Citoglipton: '), tags$span(class = "pull-right", df_patient$CITOGLIPTON)
                 ),
                 tags$li(
                   tags$strong('Metformin Rosiglitazone: '), tags$span(class = "pull-right", df_patient$metformin.rosiglitazone)
                 ),
                 tags$li(
                   tags$strong('Glyburide Metformin: '), tags$span(class = "pull-right", df_patient$GLYBURIDE.METFORMIN)
                 ),
                 tags$li(
                   tags$strong('Glipizide Metformin: '), tags$span(class = "pull-right", df_patient$GLIPIZIDE.METFORMIN)
                 ),
                 tags$li(
                   tags$strong('Glimepiride Pioglitazone: '), tags$span(class = "pull-right", df_patient$GLIMEPIRIDE.PIOGLITAZONE)
                 ),
                 tags$li(
                   tags$strong('Diabetes Medication: '), tags$span(class = "pull-right", df_patient$DIABETESMED)
                 )
                 
        )
      })
      
      
      
    })
    
    
    observeEvent(input$hide,{
      shinyjs::hide(id = "medicalbox")
    })
      
      
    observeEvent(input$prediction_button,{
      shinyjs::show(id = "explanationbox")
      #shinyjs::show(id = "predictionresult_text")
      shinyjs::hide(id="explain_plot")
      
      shinyjs::show(id = "readmissionpredictionbox")
      #shinyjs::show(id = "gauge")
      shinyjs::show(id = "ReadmissionRisk")
      

      selectedpatientnbr <- sessionVars$selectedClientId
     
      df_patient <- df_summary[df_summary$PATIENT_NBR==selectedpatientnbr,]
      df_patient$NAME <- paste(df_patient$FIRST_NAME,df_patient$LAST_NAME)
      pat_name <- df_patient$NAME
      predicted_prob=df_patient$predicted_probability*100
      predicted_prob=round(predicted_prob,1)
      output$gauge = renderGauge({
        gauge(predicted_prob, 
              symbol = '%',
              min = 0, 
              max = 100,  
              sectors = gaugeSectors(success = c(0, 10),
                                     warning = c(10, 50),
                                     danger = c(50, 100)), label = "Probability")
      })
      if(as.character(df_patient$CHANCES)=="Low"){
        licon="clipboard-check"
        lcolor="green"
      } else if(as.character(df_patient$CHANCES)=="Medium"){
        licon="th"
        lcolor="orange"
      }else{
        licon="exclamation-circle"
        lcolor="red"
      }
      output$ReadmissionRisk <- renderValueBox({

        shinydashboard::valueBox( as.character(df_patient$CHANCES),"Re-admission Risk", icon = icon(licon), color =lcolor)
      })
      
      output$predictionresult_text <- renderText({
        
        paste(pat_name,"is predicted to be",as.character(df_patient$CHANCES),"re-admission risk with a probability of",paste0(predicted_prob,"%"))
      })
      
      if(df_patient$EXPLAIN=="yes"){
        shinyjs::show(id="explanation_text")
        shinyjs::hide(id="explanation_text2")
        shinyjs::show(id="explanation_button")
        shinyjs::hide(id="explain_plot")
      } })
        
        observeEvent(input$explanation_button,{
          
          selectedpatientnbr <- sessionVars$selectedClientId
          
          df_patient <- df_summary[df_summary$PATIENT_NBR==selectedpatientnbr,]
          df_patient$NAME <- paste(df_patient$FIRST_NAME,df_patient$LAST_NAME)
          
          shinyjs::show(id="explain_plot")
          shinyjs::show(id="explanation_text2")
          
          output$explain_plot <- renderPlot({
            
            df_explain = df_lime[df_lime$PATIENT_NBR==selectedpatientnbr,]
            # df_explain$LIME_Features=droplevels(df_explain$LIME_Features)
            limefeatures=as.character(df_explain$LIME_Features)
            features=gsub('/"', "", gsub("[()]", "", as.list(unlist(strsplit(gsub("[][]", "", limefeatures), '), ')))))
            df_features=as.data.frame(features)
            df_feature_explain=data.frame(do.call("rbind", strsplit(as.character(df_features$features), "',")))
            
            names(df_feature_explain)=c("feature","weights")
            df_feature_explain$Impact_for_Prediction= ifelse(as.numeric(as.character(df_feature_explain$weights)) > 0,"Positive", "Negative")
            df_feature_explain$feature=gsub("'","",df_feature_explain$feature)
            df_feature_explain$weights = as.numeric(as.character(df_feature_explain$weights))
            df_feature_explain=df_feature_explain[order(df_feature_explain$weights),]
            df_feature_explain$feature=str_to_title(df_feature_explain$feature)
            
             ggplot(df_feature_explain, aes(x=factor(stringr::str_wrap(df_feature_explain$feature, 70), levels = df_feature_explain$feature), y=weights, label=weights),text = paste("Feature Name:",feature)) +
                geom_bar(stat='identity', aes(fill=Impact_for_Prediction), width=.5) +
                scale_fill_manual(name="Impact",
                                  labels = c("Negative", "Positive"),
                                  values = c("#e5bcf7","#7f00ba")) +
                labs(title= "Feature Importance") + xlab("Features")+ ylab("Importance") +
               theme(legend.position="bottom")+
                coord_flip() 
                
                #ggplotly(g, tooltip = "text") 
            
            
          })
          
        })
        
      
      #output$explanation<- re
    

}







