
# Load Data from CSV files
library(readr)
library(scales)

readDataset <- function(fileName) {read.csv(file.path(fileName))}
list.files()

df_summary <- readDataset("data/model-output-summary.csv")

df_lime<- readDataset("data/explanation-results.csv")
names(df_summary)
df_summary$CHANCES="Medium"
df_summary[df_summary$predicted_probability<0.07,]$CHANCES="Low"
df_summary[df_summary$predicted_probability>0.5,]$CHANCES="High"
genderlist=unique(df_summary$GENDER)
agelist = unique(df_summary$AGE)
df_summary<-  df_summary %>% mutate_at("DISCHARGE_DISPOSITION_ID", str_replace, "/transferred", "") 
df_summary<-  df_summary %>% mutate_at("DISCHARGE_DISPOSITION_ID", str_replace, "/Transferred", "") 
df_summary <-  df_summary %>% mutate_at("DISCHARGE_DISPOSITION_ID", str_replace, "/referred", "")
df_summary <-  df_summary %>% mutate_at("DISCHARGE_DISPOSITION_ID", str_replace, "Discharged to", "To")

df_summary$EXPLAIN <- "no"
df_summary[df_summary$PATIENT_NBR %in% df_lime$PATIENT_NBR,]$EXPLAIN <- "yes"

